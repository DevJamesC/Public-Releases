When setting up CI/CD for a new project you need to follow some steps.

1: create a .github directory
2: create .github/ workflows directory
3: copy the YAML (.yml) files into that directory
4: set up the required secrets in github (UNITY_LICENSCE, UNITY_EMIAL, UNITY_PASSWORD, GIT_PASSWORD)
5: set up secret API_TOKEN_GITHUB. see https://github.com/settings/tokens
6: set actions permissions in repo settings to read and write
7: set "keep artifacts and logs" to something smaller than 90 days. We output to release, so artifacts are just clutter.
8: should be good? For certain builds (such as android) extra modifications to the yaml might be required. see https://game.ci/docs/github/builder

THE YAML WORKFLOWS WILL PROBABLY NEED TO BE UPDATED TO INCLUDE SPECIFIC BUILD SETTINGS, OPTIONS, AND DEPLOYMENT STEPS FOR DIFFERENT PLATFORMS!
THE YAML WORKFLOWS DO NOT INCLUDE TESTS! SEE https://game.ci/docs/github/builder FOR SETTING UP CICD TESTS

For others to download a release, the project must be public (workaround pending) (idea: have Workflow upload zip to a 
public server somewhere?)



Make sure your game has a certificate (or that a publisher provides one. when you upload)! A game from a .zip file without a certificate will give a 
big security warning when a user tries to launch it. 

To create a certificate, go to Edit->Project Settings->Player->click windows tab->Create->follow steps. This will create a 
certificate with a 1 year expiration. For a certificate with a longer expiration use OpenSSL to create a key value pair and self signed 
certificate. To sign the certificate search the C:\ Drive for signtool.exe, find the path for any of them and run 

To refresh an expired certificate, create a new certificate, replace the old certificate in project. If for a windows appstore project
open VS, go project->store-> Associate to link the certificate in the store with the new certificate. 

NOTE: Even a game with a trusted certificate may provoke the windows defender warning! In these cases, users need to launch it with the warning
and eventually windows will realize that it is a trusted application.


Android deploy tutorial (GooglePlay): https://www.youtube.com/watch?v=sPrI_ukdT-A&ab_channel=SmartPenguins
IOS deploy tutorial: https://www.youtube.com/watch?v=kI-kGTZLEmc&ab_channel=DilmerValecillos
MACOS deploy tutorial: https://www.youtube.com/watch?v=LumsLF02DS8&ab_channel=DilmerValecillos
WINDOWS deploy tutorial: https://www.youtube.com/watch?v=TbUs_ruEQ7A&ab_channel=PolycarbonGames
WEBGL deploy tutorial (itch.io): https://www.youtube.com/watch?v=UuXZnX6cY6A&ab_channel=samyam
WEBGL deploy tutorial (Unity website) (starts at 6:00m mark): https://www.youtube.com/watch?v=UuXZnX6cY6A&ab_channel=samyam
STEAM deploy tutorial: https://www.youtube.com/watch?v=i2qC_RhEy5s&ab_channel=SkyrideStudios
